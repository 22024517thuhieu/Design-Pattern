package org.example;

public abstract class Strategy {

    public abstract void sort(int[] arr);
}
