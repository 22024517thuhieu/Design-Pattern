package org.example;

public enum Gender {
    male,
    female
}
